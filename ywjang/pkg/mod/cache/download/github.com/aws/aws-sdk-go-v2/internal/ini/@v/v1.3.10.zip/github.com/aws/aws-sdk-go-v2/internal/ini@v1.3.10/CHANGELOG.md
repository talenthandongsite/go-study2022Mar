# v1.3.10 (2022-03-30)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.9 (2022-03-24)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.8 (2022-03-23)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.7 (2022-03-08)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.6 (2022-02-24)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.5 (2022-01-28)

* **Bug Fix**: Fixes the SDK's handling of `duration_sections` in the shared credentials file or specified in multiple shared config and shared credentials files under the same profile. [#1568](https://github.com/aws/aws-sdk-go-v2/pull/1568). Thanks to [Amir Szekely](https://github.com/kichik) for help reproduce this bug.

# v1.3.4 (2022-01-14)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.3 (2022-01-07)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.2 (2021-12-02)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.1 (2021-11-19)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.0 (2021-11-06)

* **Feature**: The SDK now supports configuration of FIPS and DualStack endpoints using environment variables, shared configuration, or programmatically.
* **Dependency Update**: Updated to the latest SDK module versions

# v1.2.5 (2021-10-21)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.2.4 (2021-10-11)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.2.3 (2021-09-17)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.2.2 (2021-08-27)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.2.1 (2021-08-19)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.2.0 (2021-08-04)

* **Feature**: adds error handling for defered close calls
* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.1 (2021-07-15)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.0 (2021-07-01)

* **Feature**: Support for `:`, `=`, `[`, `]` being present in expression values.

# v1.0.1 (2021-06-25)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.0.0 (2021-05-20)

* **Release**: The `github.com/aws/aws-sdk-go-v2/internal/ini` package is now a Go Module.
* **Dependency Update**: Updated to the latest SDK module versions

